package all_time_favorites;

import java.time.DayOfWeek;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024 by Michael Inden
 */
public class SwitchExpressionsExample {
    public static void main(final String[] args) {
        DayOfWeek day = DayOfWeek.SUNDAY;

        int numOfLetters = switch (day) {
            case MONDAY, FRIDAY, SUNDAY -> {
                if (day == DayOfWeek.SUNDAY)
                    System.out.println("SUNDAY is FUN DAY");
                yield 6;
            }
            case TUESDAY -> 7;
            case THURSDAY, SATURDAY -> 8;
            case WEDNESDAY -> 9;
        };
        System.out.println(numOfLetters);
    }

}
