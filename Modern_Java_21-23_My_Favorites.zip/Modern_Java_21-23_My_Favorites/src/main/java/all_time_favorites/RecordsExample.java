package all_time_favorites;

import java.util.List;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024 by Michael Inden
 */
public class RecordsExample {

    record MyPoint(int x, int y) {
    }

    record IntStringReturnValue(int code, String info) {
    }

    record IntListReturnValue(int code, List<String> values) {
    }

    record ReturnTuple(String first, String last, int amount) {
    }

    record CompoundKey(String name, int age) {
    }

    IntStringReturnValue calculateTheAnswer() {
        // Some complex stuff here
        return new IntStringReturnValue(42, "the answer");
    }

    IntListReturnValue calculate(CompoundKey inputKey) {
        // Some complex stuff here
        return new IntListReturnValue(201, List.of("This", "is", "a", "complex", "result"));
    }

    // Pairs
    record IntIntPair(int first, int second) {
    }

    ;

    record StringIntPair(String name, int age) {
    }

    ;

    record Pair<T1, T2>(T1 first, T2 second) {
    }

    ;

    record Top3Favorites(String top1, String top2, String top3) {
    }

    ;

    record CalcResultTuple(int min, int max, double avg, int count) {
    }

    ;
}
